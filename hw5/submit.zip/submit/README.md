## Custom alg

use flag --use_counts
