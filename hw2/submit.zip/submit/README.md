Aryan Luthra's CS285 HW2 ReadMe

Please install ray using "pip3 install ray" on a UNIX machine before running my code

In order to replicate my results please run the default commands specified in the instructions with the hyperprams for each specified in the report

